# 📋 Instrucciones para Subir a GitHub

## Método 1: Subida Manual (Recomendado)

### Paso 1: Descargar los archivos
Los archivos del proyecto están en: `/mnt/okcomputer/output/euskal_choral_music_complete/`

### Paso 2: En tu ordenador local

```bash
# Clonar tu repositorio
git clone https://github.com/nejcrudel/euskal_choral_music.git
cd euskal_choral_music

# Copiar los archivos del proyecto
# (copia todo el contenido de euskal_choral_music_complete/ aquí)

# Añadir todo
git add -A

# Commit
git commit -m "Initial commit: Basque Choral Music platform

- Frontend: React + TypeScript + Tailwind + shadcn/ui
- Backend: Node.js + Express + Prisma + MariaDB
- Complete API with composers, scores, auth, favorites
- Database schema with all entities
- Seed data with sample composers and scores"

# Push
git push origin main
```

## Método 2: Usando GitHub Desktop

1. Abre GitHub Desktop
2. Selecciona tu repositorio `euskal_choral_music`
3. Copia los archivos del proyecto a la carpeta local
4. Verás los cambios en GitHub Desktop
5. Escribe un resumen del commit
6. Haz clic en "Commit to main"
7. Haz clic en "Push origin"

## 📁 Estructura del Proyecto

```
euskal_choral_music/
├── frontend/          # React + TypeScript app
│   ├── src/
│   │   ├── components/
│   │   ├── sections/
│   │   ├── pages/
│   │   ├── hooks/
│   │   ├── data/
│   │   └── types/
│   ├── package.json
│   └── ...
├── backend/           # Node.js + Express API
│   ├── prisma/
│   │   ├── schema.prisma
│   │   └── seed.js
│   ├── server.js
│   ├── package.json
│   └── ...
├── README.md
└── ARQUITECTURA_BASQUE_CHORAL_MUSIC.md
```

## 🚀 Después de subir a GitHub

### 1. Configurar Base de Datos en Plesk

1. Ve a **Bases de datos** en Plesk
2. Clic en **Añadir base de datos**
3. Configura:
   - **Nombre**: `basque_choral_music`
   - **Usuario**: `bcm_user`
   - **Contraseña**: (genera una segura)

### 2. Configurar Backend

```bash
cd backend
cp .env.example .env
# Editar .env con tus credenciales

npm install
npx prisma generate
npx prisma migrate dev --name init
npm run db:seed
npm start
```

### 3. Desplegar Frontend

```bash
cd frontend
npm install
npm run build
# Subir la carpeta 'dist' a httpdocs/ en Plesk
```

## 🔗 URLs Importantes

- **Repositorio**: https://github.com/nejcrudel/euskal_choral_music
- **Frontend demo**: https://t3dcucqmmkcqo.ok.kimi.link
- **Panel Plesk**: (tu panel de Plesk)

## 📞 Soporte

Si tienes problemas, verifica:
1. Node.js 18+ está instalado
2. MariaDB 10.6+ está funcionando
3. Las credenciales de la BD son correctas
4. El puerto 3000 está disponible
