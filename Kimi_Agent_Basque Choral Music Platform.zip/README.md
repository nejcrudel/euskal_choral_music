# 🎵 Euskal Choral Music

Plataforma de e-commerce para la venta de partituras corales vascas.

![Basque Choral Music](https://img.shields.io/badge/Basque-Choral%20Music-red)
![React](https://img.shields.io/badge/React-18-blue)
![Node.js](https://img.shields.io/badge/Node.js-18-green)
![MariaDB](https://img.shields.io/badge/MariaDB-10.11-orange)

## 📁 Estructura del Proyecto

```
euskal_choral_music/
├── frontend/           # Aplicación React + TypeScript
│   ├── src/
│   │   ├── components/   # Componentes reutilizables
│   │   ├── sections/     # Secciones de la página
│   │   ├── pages/        # Páginas/rutas
│   │   ├── hooks/        # Custom hooks (cart, auth, favorites)
│   │   ├── data/         # Datos mock
│   │   └── types/        # Tipos TypeScript
│   ├── public/
│   └── package.json
│
├── backend/            # API Node.js + Express + Prisma
│   ├── prisma/
│   │   ├── schema.prisma # Definición de BD
│   │   └── seed.js       # Datos de ejemplo
│   ├── server.js       # Servidor principal
│   ├── .env.example    # Variables de entorno
│   └── package.json
│
└── README.md           # Este archivo
```

## 🚀 Tecnologías

### Frontend
- React 18 + TypeScript
- Tailwind CSS
- shadcn/ui
- Framer Motion (animaciones)
- Lucide React (iconos)

### Backend
- Node.js + Express
- Prisma ORM
- MariaDB/MySQL
- JWT (autenticación)
- bcrypt (hash de contraseñas)
- Stripe (pagos)

## 📋 Requisitos del Servidor (Plesk)

- **Node.js**: 18+
- **MariaDB**: 10.6+ (ya tienes 10.11.16 ✅)
- **PHP**: 8.1+ (para phpMyAdmin)
- **Apache/Nginx**: con mod_proxy

## 🛠️ Instalación

### 1. Base de Datos (Plesk)

1. Ve a **Bases de datos** en Plesk
2. Clic en **Añadir base de datos**
3. Configura:
   - **Nombre**: `basque_choral_music`
   - **Usuario**: `bcm_user`
   - **Contraseña**: (genera una segura)

### 2. Backend

```bash
cd backend
npm install
cp .env.example .env
# Editar .env con tus credenciales de Plesk

npx prisma generate
npx prisma migrate dev --name init
npm run db:seed

# Desarrollo
npm run dev

# Producción
npm start
```

### 3. Frontend

```bash
cd frontend
npm install
npm run build

# Los archivos de build estarán en /dist
# Sube estos archivos a httpdocs/ en Plesk
```

## ⚙️ Configuración en Plesk

### Node.js Application

1. Ve a **Sitios web y dominios** → Tu dominio → **Configuración de Node.js**
2. Configura:
   - **Document root**: `backend`
   - **Aplicación URL**: `https://tudominio.com/api`
   - **Variables de entorno**: Copia las de tu archivo `.env`

### Proxy Inverso (Apache)

Añade al `.htaccess` en la raíz:

```apache
# Frontend (React SPA)
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^ /index.html [L]

# Backend API Proxy
RewriteRule ^api/(.*)$ http://localhost:3000/api/$1 [P,L]
```

### PM2 (Producción)

```bash
npm install -g pm2
pm2 start backend/server.js --name "euskal-api"
pm2 save
pm2 startup
```

## 🔐 Variables de Entorno (.env)

```env
# Base de datos
DATABASE_URL="mysql://usuario:password@localhost:3306/basque_choral_music"

# JWT
JWT_SECRET="tu_secreto_muy_seguro"

# Stripe
STRIPE_SECRET_KEY="sk_live_..."
STRIPE_PUBLISHABLE_KEY="pk_live_..."

# Email
SMTP_HOST="localhost"
SMTP_PORT=587
SMTP_USER="noreply@tudominio.com"
SMTP_PASS="password"

# URLs
APP_URL="https://tudominio.com"
FRONTEND_URL="https://tudominio.com"
```

## 📝 Licencia

Proyecto privado - Basque Choral Music © 2024
